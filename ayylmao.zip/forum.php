<?php
    $minPermissionLevel = 2;
    require_once("protected.php");
?>

<html>
<body>
    HELLO THIS IS THE COACHES forum
</body>
</html>
